# NovaColis Mobile App 🚚

Application mobile React Native (Expo) pour Livreurs et Clients.

---

## ⚙️ Configuration (OBLIGATOIRE avant build)

### 1. Changer l'URL de l'API
Ouvrez le fichier :
```
src/services/api.js
```
Ligne 8 — remplacez par votre domaine :
```js
export const API_BASE_URL = 'https://VOTRE-DOMAINE.COM/api/v1';
```

---

## 🚀 Build APK (étapes)

### Prérequis
- Node.js 18+
- Compte Expo : https://expo.dev (gratuit)

### Étape 1 — Installer les dépendances
```bash
npm install
```

### Étape 2 — Installer EAS CLI
```bash
npm install -g eas-cli
```

### Étape 3 — Se connecter à Expo
```bash
eas login
```

### Étape 4 — Builder l'APK
```bash
eas build --platform android --profile preview
```
→ Le build se fait sur les serveurs Expo (pas besoin d'Android Studio)
→ Vous recevez un lien de téléchargement APK dans 5-10 minutes

---

## 📱 Tester localement (sans build)

```bash
npm install
npx expo start
```
→ Scanner le QR code avec l'app **Expo Go** sur votre téléphone

---

## 📂 Structure des fichiers

```
NovaColis/
├── App.js                          # Point d'entrée
├── app.json                        # Config Expo
├── eas.json                        # Config build APK
├── src/
│   ├── services/
│   │   └── api.js                  # ⚠️ URL API ici
│   ├── context/
│   │   └── AuthContext.js          # Auth (login/logout)
│   ├── navigation/
│   │   └── AppNavigator.js         # Routing selon rôle
│   └── screens/
│       ├── LoginScreen.js          # Connexion
│       ├── LivreurDashboard.js     # Dashboard livreur
│       ├── ClientDashboard.js      # Dashboard client
│       ├── ColisDetailScreen.js    # Détail + changer statut
│       ├── ScanScreen.js           # Scanner QR (livreur)
│       ├── NouveauColisScreen.js   # Créer colis (client)
│       └── ProfileScreen.js       # Profil + déconnexion
```

---

## 🔑 Fonctionnalités

### Livreur
- ✅ Login avec token sécurisé
- ✅ Dashboard avec stats (total, livrés, en livraison, retournés)
- ✅ Liste colis avec filtres par statut
- ✅ Détail colis + changer statut (livré, retourné, refusé...)
- ✅ Scanner QR Code

### Client
- ✅ Login avec token sécurisé
- ✅ Dashboard avec stats
- ✅ Liste colis avec recherche + filtres
- ✅ Créer un nouveau colis
- ✅ Détail colis

---

## 🆔 Identifiants de test
Les mêmes identifiants que le site web (email + mot de passe).
Le rôle est détecté automatiquement (livreur → interface livreur, client → interface client).
