// ============================================================
// NovaColis - API Service
// Modifiez API_BASE_URL avec l'URL de votre serveur
// ============================================================

import * as SecureStore from 'expo-secure-store';

// ⚠️ IMPORTANT: Changez cette URL avec votre domaine
export const API_BASE_URL = 'https://VOTRE-DOMAINE.COM/api/v1';

// ============================================================
// Token management
// ============================================================
export const saveToken = async (token) => {
  await SecureStore.setItemAsync('auth_token', token);
};

export const getToken = async () => {
  return await SecureStore.getItemAsync('auth_token');
};

export const removeToken = async () => {
  await SecureStore.deleteItemAsync('auth_token');
};

export const saveUser = async (user) => {
  await SecureStore.setItemAsync('auth_user', JSON.stringify(user));
};

export const getUser = async () => {
  const u = await SecureStore.getItemAsync('auth_user');
  return u ? JSON.parse(u) : null;
};

export const removeUser = async () => {
  await SecureStore.deleteItemAsync('auth_user');
};

// ============================================================
// API calls helper
// ============================================================
const apiFetch = async (endpoint, options = {}) => {
  const token = await getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Erreur serveur');
  }

  return data;
};

// ============================================================
// Auth
// ============================================================
export const login = async (email, password) => {
  const data = await apiFetch('/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  return data.data;
};

// ============================================================
// Colis
// ============================================================
export const getColis = async (params = {}) => {
  const query = new URLSearchParams(params).toString();
  const data = await apiFetch(`/colis${query ? '?' + query : ''}`);
  return data.data;
};

export const getColisDetail = async (id) => {
  const data = await apiFetch(`/colis/${id}`);
  return data.data;
};

export const updateStatut = async (id, statut, motif = '') => {
  const data = await apiFetch(`/colis/${id}/statut`, {
    method: 'PUT',
    body: JSON.stringify({ statut, motif }),
  });
  return data.data;
};

export const createColis = async (colisData) => {
  const data = await apiFetch('/colis', {
    method: 'POST',
    body: JSON.stringify(colisData),
  });
  return data.data;
};

// ============================================================
// Stats
// ============================================================
export const getLivreurStats = async () => {
  const data = await apiFetch('/livreur/stats');
  return data.data;
};

export const getClientStats = async () => {
  const data = await apiFetch('/client/stats');
  return data.data;
};

// ============================================================
// Tracking public
// ============================================================
export const getTracking = async (code) => {
  const data = await apiFetch(`/tracking/${code}`);
  return data.data;
};

// ============================================================
// Scan QR
// ============================================================
export const scanColis = async (tracking_code) => {
  const data = await apiFetch('/scan', {
    method: 'POST',
    body: JSON.stringify({ tracking_code }),
  });
  return data.data;
};

// ============================================================
// Villes
// ============================================================
export const getVilles = async () => {
  const data = await apiFetch('/villes');
  return data.data;
};

// ============================================================
// Profile
// ============================================================
export const getMe = async () => {
  const data = await apiFetch('/me');
  return data.data;
};

export const updateMe = async (updates) => {
  const data = await apiFetch('/me', {
    method: 'PUT',
    body: JSON.stringify(updates),
  });
  return data.data;
};
