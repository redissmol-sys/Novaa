import React, { createContext, useContext, useState, useEffect } from 'react';
import { login as apiLogin, saveToken, saveUser, getToken, getUser, removeToken, removeUser } from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const token = await getToken();
        const u     = await getUser();
        if (token && u) setUser(u);
      } catch (e) {}
      setLoading(false);
    })();
  }, []);

  const login = async (email, password) => {
    const data = await apiLogin(email, password);
    await saveToken(data.token);
    await saveUser(data.user);
    setUser(data.user);
    return data.user;
  };

  const logout = async () => {
    await removeToken();
    await removeUser();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
