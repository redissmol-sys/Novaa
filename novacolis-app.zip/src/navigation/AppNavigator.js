import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator }     from '@react-navigation/stack';
import { Ionicons }                 from '@expo/vector-icons';

import { useAuth }            from '../context/AuthContext';
import LoginScreen            from '../screens/LoginScreen';
import LivreurDashboard       from '../screens/LivreurDashboard';
import ClientDashboard        from '../screens/ClientDashboard';
import ColisDetailScreen      from '../screens/ColisDetailScreen';
import ScanScreen             from '../screens/ScanScreen';
import NouveauColisScreen     from '../screens/NouveauColisScreen';
import ProfileScreen          from '../screens/ProfileScreen';
import { ActivityIndicator, View } from 'react-native';

const Tab   = createBottomTabNavigator();
const Stack = createStackNavigator();

// ── Livreur stack ──────────────────────────────────────────
function LivreurStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#1C5BDB' }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '700' } }}>
      <Stack.Screen name="Dashboard" component={LivreurDashboard} options={{ headerShown: false }} />
      <Stack.Screen name="ColisDetail" component={ColisDetailScreen} options={{ title: 'Détail colis' }} />
      <Stack.Screen name="Scan" component={ScanScreen} options={{ title: 'Scanner QR' }} />
    </Stack.Navigator>
  );
}

// ── Client stack ───────────────────────────────────────────
function ClientStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: '#1C5BDB' }, headerTintColor: '#fff', headerTitleStyle: { fontWeight: '700' } }}>
      <Stack.Screen name="Dashboard"    component={ClientDashboard}   options={{ headerShown: false }} />
      <Stack.Screen name="ColisDetail"  component={ColisDetailScreen} options={{ title: 'Détail colis' }} />
      <Stack.Screen name="NouveauColis" component={NouveauColisScreen} options={{ title: 'Nouveau Colis' }} />
    </Stack.Navigator>
  );
}

// ── Tab navigators ─────────────────────────────────────────
function LivreurTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#1C5BDB',
        tabBarInactiveTintColor: '#9CA3AF',
        tabBarStyle: { borderTopWidth: 1, borderTopColor: '#F3F4F6', height: 60, paddingBottom: 8 },
        tabBarIcon: ({ focused, color, size }) => {
          const icons = { Colis: focused ? 'cube' : 'cube-outline', Scanner: focused ? 'qr-code' : 'qr-code-outline', Profil: focused ? 'person' : 'person-outline' };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Colis"   component={LivreurStack} />
      <Tab.Screen name="Scanner" component={ScanScreen}   />
      <Tab.Screen name="Profil"  component={ProfileScreen}/>
    </Tab.Navigator>
  );
}

function ClientTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#1C5BDB',
        tabBarInactiveTintColor: '#9CA3AF',
        tabBarStyle: { borderTopWidth: 1, borderTopColor: '#F3F4F6', height: 60, paddingBottom: 8 },
        tabBarIcon: ({ focused, color, size }) => {
          const icons = { 'Mes Colis': focused ? 'cube' : 'cube-outline', Nouveau: focused ? 'add-circle' : 'add-circle-outline', Profil: focused ? 'person' : 'person-outline' };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Mes Colis" component={ClientStack}        />
      <Tab.Screen name="Nouveau"   component={NouveauColisScreen} options={{ headerShown: true, headerStyle: { backgroundColor: '#1C5BDB' }, headerTintColor: '#fff', title: 'Nouveau Colis' }} />
      <Tab.Screen name="Profil"    component={ProfileScreen}      />
    </Tab.Navigator>
  );
}

// ── Root ───────────────────────────────────────────────────
export default function AppNavigator() {
  const { user, loading } = useAuth();

  if (loading) return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color="#1C5BDB" />
    </View>
  );

  return (
    <NavigationContainer>
      {!user
        ? <Stack.Navigator screenOptions={{ headerShown: false }}><Stack.Screen name="Login" component={LoginScreen} /></Stack.Navigator>
        : user.role === 'livreur'
          ? <LivreurTabs />
          : <ClientTabs />
      }
    </NavigationContainer>
  );
}
