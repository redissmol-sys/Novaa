import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { API_BASE_URL } from '../services/api';

export default function ProfileScreen() {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert('Déconnexion', 'Voulez-vous vous déconnecter ?', [
      { text: 'Annuler', style: 'cancel' },
      { text: 'Déconnecter', style: 'destructive', onPress: logout },
    ]);
  };

  const InfoRow = ({ icon, label, value }) => (
    <View style={styles.row}>
      <Ionicons name={icon} size={18} color="#6B7280" style={styles.rowIcon} />
      <View>
        <Text style={styles.rowLabel}>{label}</Text>
        <Text style={styles.rowVal}>{value || '—'}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Avatar */}
      <View style={styles.avatarBox}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {(user?.prenom?.[0] || '') + (user?.nom?.[0] || '')}
          </Text>
        </View>
        <Text style={styles.name}>{user?.prenom} {user?.nom}</Text>
        <View style={styles.roleBadge}>
          <Text style={styles.roleText}>{user?.role?.toUpperCase()}</Text>
        </View>
      </View>

      {/* Infos */}
      <View style={styles.card}>
        <InfoRow icon="mail-outline"      label="Email"     value={user?.email} />
        <InfoRow icon="call-outline"      label="Téléphone" value={user?.telephone} />
        <InfoRow icon="server-outline"    label="API URL"   value={API_BASE_URL} />
      </View>

      {/* Logout */}
      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={20} color="#DC2626" />
        <Text style={styles.logoutText}>Se déconnecter</Text>
      </TouchableOpacity>

      <Text style={styles.version}>NovaColis v1.0.0</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container:   { flex: 1, backgroundColor: '#F8FAFC' },
  avatarBox:   { alignItems: 'center', paddingTop: 40, paddingBottom: 24, backgroundColor: '#1C5BDB' },
  avatar:      { width: 72, height: 72, borderRadius: 36, backgroundColor: 'rgba(255,255,255,0.25)', justifyContent: 'center', alignItems: 'center', marginBottom: 10 },
  avatarText:  { color: '#fff', fontSize: 26, fontWeight: '800' },
  name:        { color: '#fff', fontSize: 20, fontWeight: '700' },
  roleBadge:   { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20, marginTop: 6 },
  roleText:    { color: '#fff', fontSize: 11, fontWeight: '700' },
  card:        { backgroundColor: '#fff', margin: 16, borderRadius: 14, padding: 6, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  row:         { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  rowIcon:     { marginRight: 12 },
  rowLabel:    { fontSize: 11, color: '#9CA3AF', marginBottom: 1 },
  rowVal:      { fontSize: 14, color: '#111827', fontWeight: '600' },
  logoutBtn:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, margin: 16, padding: 14, borderRadius: 12, backgroundColor: '#FEF2F2', borderWidth: 1, borderColor: '#FECACA' },
  logoutText:  { color: '#DC2626', fontWeight: '700', fontSize: 15 },
  version:     { textAlign: 'center', color: '#9CA3AF', fontSize: 12, marginTop: 8 },
});
