import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  ActivityIndicator, Alert, Modal, TextInput
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getColisDetail, updateStatut } from '../services/api';
import { useAuth } from '../context/AuthContext';

const STATUTS_LIVREUR = [
  { key: 'en_livraison', label: 'En livraison', icon: 'bicycle', color: '#EA580C' },
  { key: 'livre',        label: 'Livré ✅',     icon: 'checkmark-circle', color: '#16A34A' },
  { key: 'reporte',      label: 'Reporté',      icon: 'time', color: '#D97706' },
  { key: 'retourne',     label: 'Retourné',     icon: 'return-down-back', color: '#DC2626' },
  { key: 'refuse',       label: 'Refusé',       icon: 'close-circle', color: '#7C3AED' },
];

const STATUTS_CLIENT = [
  { key: 'annule', label: 'Annuler', icon: 'close-circle', color: '#DC2626' },
];

export default function ColisDetailScreen({ route }) {
  const { id } = route.params;
  const { user } = useAuth();
  const [colis,   setColis]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [modal,   setModal]   = useState(false);
  const [newStat, setNewStat] = useState('');
  const [motif,   setMotif]   = useState('');
  const [saving,  setSaving]  = useState(false);

  useEffect(() => { loadDetail(); }, []);

  const loadDetail = async () => {
    try {
      const d = await getColisDetail(id);
      setColis(d.colis);
    } catch (e) {}
    setLoading(false);
  };

  const openModal = (statut) => {
    setNewStat(statut);
    setMotif('');
    setModal(true);
  };

  const confirmerStatut = async () => {
    const needsMotif = ['retourne', 'annule', 'refuse'].includes(newStat);
    if (needsMotif && !motif.trim()) {
      Alert.alert('Motif requis', 'Veuillez saisir un motif pour ce statut.');
      return;
    }
    setSaving(true);
    try {
      await updateStatut(id, newStat, motif);
      setModal(false);
      await loadDetail();
      Alert.alert('✅ Succès', 'Statut mis à jour.');
    } catch (e) {
      Alert.alert('Erreur', e.message);
    }
    setSaving(false);
  };

  const statuts = user?.role === 'livreur' ? STATUTS_LIVREUR : STATUTS_CLIENT;
  const needsMotif = ['retourne', 'annule', 'refuse'].includes(newStat);

  const InfoRow = ({ label, value }) => (
    <View style={styles.infoRow}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoVal}>{value || '—'}</Text>
    </View>
  );

  if (loading) return <View style={styles.center}><ActivityIndicator size="large" color="#1C5BDB" /></View>;
  if (!colis)  return <View style={styles.center}><Text>Colis introuvable</Text></View>;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Tracking header */}
      <View style={styles.trackingHeader}>
        <Text style={styles.trackingCode}>{colis.tracking_code}</Text>
        <View style={styles.statutBadge}>
          <Text style={styles.statutText}>{colis.statut?.toUpperCase()}</Text>
        </View>
      </View>

      {/* Destinataire */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}><Ionicons name="person" size={14} /> Destinataire</Text>
        <InfoRow label="Nom"       value={colis.destinataire_nom} />
        <InfoRow label="Téléphone" value={colis.destinataire_telephone} />
        <InfoRow label="Adresse"   value={colis.destinataire_adresse} />
        <InfoRow label="Ville"     value={colis.ville_destination_nom} />
      </View>

      {/* Infos colis */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}><Ionicons name="cube" size={14} /> Colis</Text>
        <InfoRow label="COD"        value={colis.cod_montant ? `${colis.cod_montant} MAD` : '0'} />
        <InfoRow label="Poids"      value={colis.poids ? `${colis.poids} kg` : '—'} />
        <InfoRow label="Articles"   value={colis.nb_articles} />
        <InfoRow label="Type"       value={colis.priorite} />
        {colis.notes ? <InfoRow label="Notes" value={colis.notes} /> : null}
      </View>

      {/* Actions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Changer le statut</Text>
        {statuts.map(s => (
          <TouchableOpacity
            key={s.key}
            style={[styles.actionBtn, { borderColor: s.color }]}
            onPress={() => openModal(s.key)}
          >
            <Ionicons name={s.icon} size={18} color={s.color} />
            <Text style={[styles.actionText, { color: s.color }]}>{s.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Modal confirmation */}
      <Modal visible={modal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Confirmer: {newStat}</Text>
            {needsMotif && (
              <TextInput
                style={styles.motifInput}
                placeholder="Motif obligatoire..."
                value={motif}
                onChangeText={setMotif}
                multiline
              />
            )}
            <View style={styles.modalBtns}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setModal(false)}>
                <Text style={{ color: '#6B7280', fontWeight: '600' }}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.confirmBtn} onPress={confirmerStatut} disabled={saving}>
                {saving ? <ActivityIndicator color="#fff" size="small" /> : <Text style={{ color: '#fff', fontWeight: '700' }}>Confirmer</Text>}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:      { flex: 1, backgroundColor: '#F8FAFC' },
  center:         { flex: 1, justifyContent: 'center', alignItems: 'center' },
  trackingHeader: { backgroundColor: '#1C5BDB', padding: 20, paddingTop: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  trackingCode:   { color: '#fff', fontSize: 18, fontWeight: '800' },
  statutBadge:    { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20 },
  statutText:     { color: '#fff', fontSize: 12, fontWeight: '700' },
  section:        { backgroundColor: '#fff', margin: 12, borderRadius: 14, padding: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  sectionTitle:   { fontSize: 13, fontWeight: '700', color: '#374151', marginBottom: 12 },
  infoRow:        { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  infoLabel:      { fontSize: 13, color: '#6B7280' },
  infoVal:        { fontSize: 13, fontWeight: '600', color: '#111827', maxWidth: '60%', textAlign: 'right' },
  actionBtn:      { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 13, borderRadius: 10, borderWidth: 1.5, marginBottom: 8 },
  actionText:     { fontSize: 14, fontWeight: '700' },
  modalOverlay:   { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalCard:      { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 24 },
  modalTitle:     { fontSize: 17, fontWeight: '700', color: '#111827', marginBottom: 16 },
  motifInput:     { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, fontSize: 14, minHeight: 80, textAlignVertical: 'top', marginBottom: 16 },
  modalBtns:      { flexDirection: 'row', gap: 12 },
  cancelBtn:      { flex: 1, padding: 14, borderRadius: 10, backgroundColor: '#F3F4F6', alignItems: 'center' },
  confirmBtn:     { flex: 1, padding: 14, borderRadius: 10, backgroundColor: '#1C5BDB', alignItems: 'center' },
});
