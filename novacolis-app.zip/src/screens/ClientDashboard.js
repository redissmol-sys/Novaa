import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, RefreshControl,
  TouchableOpacity, ActivityIndicator, TextInput
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { getClientStats, getColis } from '../services/api';

const STATUTS = [
  { key: '',             label: 'Tous',        color: '#6B7280' },
  { key: 'nouveau',      label: 'Nouveau',     color: '#2563EB' },
  { key: 'en_livraison', label: 'En cours',    color: '#EA580C' },
  { key: 'livre',        label: 'Livré',       color: '#16A34A' },
  { key: 'retourne',     label: 'Retourné',    color: '#DC2626' },
  { key: 'annule',       label: 'Annulé',      color: '#6B7280' },
];

export default function ClientDashboard({ navigation }) {
  const { user } = useAuth();
  const [stats,      setStats]      = useState(null);
  const [colis,      setColis]      = useState([]);
  const [statut,     setStatut]     = useState('');
  const [search,     setSearch]     = useState('');
  const [loading,    setLoading]    = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, c] = await Promise.all([
        getClientStats(),
        getColis({ statut, q: search, limit: 30 }),
      ]);
      setStats(s);
      setColis(c.colis || []);
    } catch (e) {}
    setLoading(false);
    setRefreshing(false);
  }, [statut, search]);

  useEffect(() => { load(); }, [load]);

  const StatCard = ({ icon, label, value, color }) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <Ionicons name={icon} size={20} color={color} />
      <Text style={styles.statVal}>{value ?? 0}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );

  const getStatutStyle = (s) => {
    const map = {
      nouveau:      { bg: '#EFF6FF', color: '#2563EB' },
      en_livraison: { bg: '#FFF7ED', color: '#EA580C' },
      livre:        { bg: '#F0FDF4', color: '#16A34A' },
      retourne:     { bg: '#FEF2F2', color: '#DC2626' },
      annule:       { bg: '#F3F4F6', color: '#6B7280' },
      en_transit:   { bg: '#ECFDF5', color: '#059669' },
      ramasse:      { bg: '#F5F3FF', color: '#7C3AED' },
    };
    return map[s] || { bg: '#F3F4F6', color: '#6B7280' };
  };

  if (loading) return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color="#1C5BDB" />
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.welcome}>Bonjour 👋</Text>
          <Text style={styles.name}>{user?.prenom} {user?.nom}</Text>
        </View>
        <TouchableOpacity
          style={styles.newBtn}
          onPress={() => navigation.navigate('NouveauColis')}
        >
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.newBtnText}>Nouveau</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} />}
        showsVerticalScrollIndicator={false}
      >
        {/* Stats */}
        {stats && (
          <View style={styles.statsGrid}>
            <StatCard icon="cube-outline"     label="Total"    value={stats.total}    color="#6B7280" />
            <StatCard icon="checkmark-circle" label="Livrés"   value={stats.livres}   color="#16A34A" />
            <StatCard icon="time-outline"     label="En cours" value={stats.en_cours} color="#EA580C" />
            <StatCard icon="return-down-back" label="Retours"  value={stats.retournes}color="#DC2626" />
          </View>
        )}

        {/* Search */}
        <View style={styles.searchBox}>
          <Ionicons name="search" size={16} color="#9CA3AF" />
          <TextInput
            style={styles.searchInput}
            placeholder="Rechercher un colis..."
            placeholderTextColor="#9CA3AF"
            value={search}
            onChangeText={setSearch}
            onSubmitEditing={load}
            returnKeyType="search"
          />
        </View>

        {/* Filtres */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll}>
          {STATUTS.map(s => (
            <TouchableOpacity
              key={s.key}
              style={[styles.filterBtn, statut === s.key && { backgroundColor: s.color }]}
              onPress={() => setStatut(s.key)}
            >
              <Text style={[styles.filterText, statut === s.key && { color: '#fff' }]}>{s.label}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Liste colis */}
        <Text style={styles.sectionTitle}>Mes Colis ({colis.length})</Text>
        {colis.length === 0 && (
          <View style={styles.emptyBox}>
            <Ionicons name="cube-outline" size={40} color="#D1D5DB" />
            <Text style={styles.emptyText}>Aucun colis trouvé</Text>
          </View>
        )}
        {colis.map(c => {
          const st = getStatutStyle(c.statut);
          return (
            <TouchableOpacity
              key={c.id}
              style={styles.colisCard}
              onPress={() => navigation.navigate('ColisDetail', { id: c.id })}
            >
              <View style={styles.colisRow}>
                <Text style={styles.tracking}>{c.tracking_code}</Text>
                <View style={[styles.badge, { backgroundColor: st.bg }]}>
                  <Text style={[styles.badgeText, { color: st.color }]}>{c.statut}</Text>
                </View>
              </View>
              <Text style={styles.dest}>{c.destinataire_nom}</Text>
              <View style={styles.colisFooter}>
                <Text style={styles.ville}>
                  <Ionicons name="location-outline" size={11} /> {c.ville_destination}
                </Text>
                {c.cod_montant > 0 && (
                  <Text style={styles.cod}>💰 {c.cod_montant} MAD</Text>
                )}
              </View>
            </TouchableOpacity>
          );
        })}
        <View style={{ height: 20 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:    { flex: 1, backgroundColor: '#F8FAFC' },
  center:       { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header:       { backgroundColor: '#1C5BDB', padding: 20, paddingTop: 50, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  welcome:      { color: 'rgba(255,255,255,0.8)', fontSize: 13 },
  name:         { color: '#fff', fontSize: 18, fontWeight: '700' },
  newBtn:       { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  newBtnText:   { color: '#fff', fontWeight: '700', fontSize: 13 },
  statsGrid:    { flexDirection: 'row', flexWrap: 'wrap', padding: 12, gap: 8 },
  statCard:     { flex: 1, minWidth: '45%', backgroundColor: '#fff', borderRadius: 12, padding: 14, borderLeftWidth: 3, alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  statVal:      { fontSize: 22, fontWeight: '800', color: '#111827', marginTop: 4 },
  statLabel:    { fontSize: 11, color: '#6B7280', marginTop: 2 },
  searchBox:    { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8, paddingHorizontal: 12, borderRadius: 10, gap: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  searchInput:  { flex: 1, paddingVertical: 10, fontSize: 14, color: '#111827' },
  filterScroll: { paddingHorizontal: 12, marginBottom: 8 },
  filterBtn:    { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#F3F4F6', marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  filterText:   { fontSize: 13, color: '#374151', fontWeight: '600' },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: '#374151', paddingHorizontal: 16, marginBottom: 8 },
  emptyBox:     { alignItems: 'center', paddingVertical: 40 },
  emptyText:    { color: '#9CA3AF', marginTop: 10, fontSize: 14 },
  colisCard:    { backgroundColor: '#fff', marginHorizontal: 12, marginBottom: 8, borderRadius: 12, padding: 14, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  colisRow:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  tracking:     { fontSize: 14, fontWeight: '700', color: '#1C5BDB' },
  badge:        { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 },
  badgeText:    { fontSize: 11, fontWeight: '700' },
  dest:         { fontSize: 14, fontWeight: '600', color: '#111827' },
  colisFooter:  { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  ville:        { fontSize: 12, color: '#6B7280' },
  cod:          { fontSize: 12, color: '#16A34A', fontWeight: '600' },
});
