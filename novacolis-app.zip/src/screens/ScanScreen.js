import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { Ionicons } from '@expo/vector-icons';
import { scanColis } from '../services/api';

export default function ScanScreen({ navigation }) {
  const [hasPermission, setHasPermission] = useState(null);
  const [scanned,  setScanned]  = useState(false);
  const [loading,  setLoading]  = useState(false);

  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  const handleScan = async ({ data }) => {
    if (scanned || loading) return;
    setScanned(true);
    setLoading(true);
    try {
      // data peut être un JSON ou directement le tracking code
      let tracking = data;
      try {
        const parsed = JSON.parse(data);
        tracking = parsed.tracking || data;
      } catch {}

      const result = await scanColis(tracking);
      navigation.navigate('ColisDetail', { id: result.colis.id });
    } catch (e) {
      Alert.alert('Erreur', e.message || 'Colis introuvable');
    }
    setLoading(false);
  };

  if (hasPermission === null) return <View style={styles.center}><ActivityIndicator color="#1C5BDB" /></View>;
  if (hasPermission === false) return (
    <View style={styles.center}>
      <Ionicons name="camera-off" size={48} color="#9CA3AF" />
      <Text style={styles.noCamera}>Accès caméra refusé</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <BarCodeScanner
        onBarCodeScanned={scanned ? undefined : handleScan}
        style={StyleSheet.absoluteFillObject}
      />

      {/* Overlay */}
      <View style={styles.overlay}>
        <Text style={styles.title}>Scanner un colis</Text>
        <View style={styles.scanBox}>
          <View style={[styles.corner, styles.tl]} />
          <View style={[styles.corner, styles.tr]} />
          <View style={[styles.corner, styles.bl]} />
          <View style={[styles.corner, styles.br]} />
          {loading && <ActivityIndicator size="large" color="#fff" />}
        </View>
        <Text style={styles.hint}>Pointez vers le QR Code du colis</Text>

        {scanned && !loading && (
          <TouchableOpacity style={styles.rescanBtn} onPress={() => setScanned(false)}>
            <Ionicons name="refresh" size={18} color="#fff" />
            <Text style={styles.rescanText}>Scanner à nouveau</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  center:    { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#F8FAFC' },
  noCamera:  { color: '#6B7280', marginTop: 12, fontSize: 15 },
  overlay:   { flex: 1, justifyContent: 'space-between', alignItems: 'center', paddingTop: 60, paddingBottom: 60, backgroundColor: 'rgba(0,0,0,0.4)' },
  title:     { color: '#fff', fontSize: 20, fontWeight: '700' },
  scanBox:   { width: 240, height: 240, justifyContent: 'center', alignItems: 'center' },
  corner:    { position: 'absolute', width: 30, height: 30, borderColor: '#fff', borderWidth: 3 },
  tl: { top: 0, left: 0,  borderRightWidth: 0, borderBottomWidth: 0 },
  tr: { top: 0, right: 0, borderLeftWidth: 0,  borderBottomWidth: 0 },
  bl: { bottom: 0, left: 0,  borderRightWidth: 0, borderTopWidth: 0 },
  br: { bottom: 0, right: 0, borderLeftWidth: 0,  borderTopWidth: 0 },
  hint:      { color: 'rgba(255,255,255,0.8)', fontSize: 14 },
  rescanBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#1C5BDB', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 20 },
  rescanText:{ color: '#fff', fontWeight: '600', fontSize: 14 },
});
