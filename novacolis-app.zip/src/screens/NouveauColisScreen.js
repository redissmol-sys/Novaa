import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TextInput,
  TouchableOpacity, ActivityIndicator, Alert
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createColis, getVilles } from '../services/api';

export default function NouveauColisScreen({ navigation }) {
  const [villes,  setVilles]  = useState([]);
  const [loading, setLoading] = useState(false);
  const [form,    setForm]    = useState({
    destinataire_nom:       '',
    destinataire_telephone: '',
    destinataire_adresse:   '',
    ville_destination:      '',
    cod_montant:            '',
    poids:                  '1',
    nb_articles:            '1',
    description:            '',
    notes:                  '',
    priorite:               'normal',
  });

  useEffect(() => {
    getVilles().then(v => setVilles(v || [])).catch(() => {});
  }, []);

  const set = (key, val) => setForm(prev => ({ ...prev, [key]: val }));

  const submit = async () => {
    if (!form.destinataire_nom || !form.destinataire_telephone || !form.ville_destination) {
      Alert.alert('Erreur', 'Nom, téléphone et ville sont obligatoires.');
      return;
    }
    setLoading(true);
    try {
      const res = await createColis({
        ...form,
        cod_montant:  parseFloat(form.cod_montant)  || 0,
        poids:        parseFloat(form.poids)         || 1,
        nb_articles:  parseInt(form.nb_articles)     || 1,
        ville_destination: parseInt(form.ville_destination),
      });
      Alert.alert('✅ Colis créé', `Tracking: ${res.tracking_code}`, [
        { text: 'OK', onPress: () => navigation.goBack() }
      ]);
    } catch (e) {
      Alert.alert('Erreur', e.message);
    }
    setLoading(false);
  };

  const Field = ({ label, keyName, placeholder, keyboardType = 'default', multiline = false }) => (
    <View style={styles.fieldBox}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={[styles.input, multiline && styles.inputMulti]}
        placeholder={placeholder || label}
        placeholderTextColor="#9CA3AF"
        value={form[keyName]}
        onChangeText={v => set(keyName, v)}
        keyboardType={keyboardType}
        multiline={multiline}
      />
    </View>
  );

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}><Ionicons name="person" size={14} /> Destinataire</Text>
        <Field label="Nom complet *"  keyName="destinataire_nom"       />
        <Field label="Téléphone *"    keyName="destinataire_telephone"  keyboardType="phone-pad" />
        <Field label="Adresse"        keyName="destinataire_adresse"    />
      </View>

      {/* Ville destination */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}><Ionicons name="location" size={14} /> Ville destination *</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {villes.map(v => (
            <TouchableOpacity
              key={v.id}
              style={[styles.villeBtn, form.ville_destination == v.id && styles.villeBtnActive]}
              onPress={() => set('ville_destination', v.id.toString())}
            >
              <Text style={[styles.villeBtnText, form.ville_destination == v.id && { color: '#fff' }]}>
                {v.nom}
              </Text>
              {v.tarif_livraison > 0 && (
                <Text style={[styles.villePrice, form.ville_destination == v.id && { color: 'rgba(255,255,255,0.8)' }]}>
                  {v.tarif_livraison} MAD
                </Text>
              )}
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Détails colis */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}><Ionicons name="cube" size={14} /> Détails colis</Text>
        <Field label="Montant COD (MAD)" keyName="cod_montant"  keyboardType="numeric" />
        <Field label="Poids (kg)"        keyName="poids"        keyboardType="numeric" />
        <Field label="Nb articles"       keyName="nb_articles"  keyboardType="numeric" />
        <Field label="Description"       keyName="description"  multiline />
        <Field label="Notes internes"    keyName="notes"        multiline />
      </View>

      {/* Priorité */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Priorité</Text>
        <View style={styles.prioriteRow}>
          {['normal', 'urgent', 'fragile'].map(p => (
            <TouchableOpacity
              key={p}
              style={[styles.prioriteBtn, form.priorite === p && styles.prioriteBtnActive]}
              onPress={() => set('priorite', p)}
            >
              <Text style={[styles.prioriteText, form.priorite === p && { color: '#fff' }]}>
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <TouchableOpacity style={styles.submitBtn} onPress={submit} disabled={loading}>
        {loading
          ? <ActivityIndicator color="#fff" />
          : <><Ionicons name="checkmark-circle" size={18} color="#fff" /><Text style={styles.submitText}>Créer le colis</Text></>
        }
      </TouchableOpacity>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: '#F8FAFC' },
  section:         { backgroundColor: '#fff', margin: 12, borderRadius: 14, padding: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  sectionTitle:    { fontSize: 13, fontWeight: '700', color: '#374151', marginBottom: 12 },
  fieldBox:        { marginBottom: 12 },
  label:           { fontSize: 12, color: '#6B7280', marginBottom: 4, fontWeight: '600' },
  input:           { borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, padding: 12, fontSize: 14, color: '#111827', backgroundColor: '#F9FAFB' },
  inputMulti:      { minHeight: 70, textAlignVertical: 'top' },
  villeBtn:        { paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, backgroundColor: '#F3F4F6', marginRight: 8, borderWidth: 1, borderColor: '#E5E7EB', alignItems: 'center' },
  villeBtnActive:  { backgroundColor: '#1C5BDB', borderColor: '#1C5BDB' },
  villeBtnText:    { fontSize: 13, fontWeight: '700', color: '#374151' },
  villePrice:      { fontSize: 11, color: '#6B7280', marginTop: 2 },
  prioriteRow:     { flexDirection: 'row', gap: 8 },
  prioriteBtn:     { flex: 1, padding: 10, borderRadius: 10, backgroundColor: '#F3F4F6', alignItems: 'center', borderWidth: 1, borderColor: '#E5E7EB' },
  prioriteBtnActive:{ backgroundColor: '#1C5BDB', borderColor: '#1C5BDB' },
  prioriteText:    { fontSize: 13, fontWeight: '700', color: '#374151' },
  submitBtn:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#1C5BDB', margin: 12, padding: 16, borderRadius: 14 },
  submitText:      { color: '#fff', fontWeight: '700', fontSize: 16 },
});
